<?php
header("Location:pages/main/adminsInfo.php");
?>
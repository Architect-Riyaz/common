 <footer class="main-footer">
    
    <strong>Copyright &copy; 2019<a href="#">XYZ</a>.</strong> All rights
    reserved.
  </footer>
